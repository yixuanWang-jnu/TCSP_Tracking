function results = run_TCSP(seq, r, res_path, bSaveImage, parameters)
% Set tracker parameters and run tracker
% Input  : seq[structure](sequence information)
% Output : results[structure](tracking results)
% [1] Wu Y, Lim J, Yang MH. Object tracking benchmark. IEEE Transactions on 
% Pattern Analysis and Machine Intelligence. 2015 Sep 1;37(9):1834-48.
% [2] Danelljan M, Bhat G, Khan FS, Felsberg M. ECO: Efficient Convolution 
% Operators for Tracking. InCVPR 2017.

% Set feature parameters
hog_params.cell_size = 6;
hog_params.feature_is_deep = false;

cn_params.tablename = 'CNnorm';
cn_params.useForGray = false;
cn_params.cell_size = 4;
cn_params.nDim = 10;
cn_params.feature_is_deep = false;       

ic_params.tablename = 'intensityChannelNorm6';
ic_params.useForColor = false;
ic_params.cell_size = 4;
ic_params.feature_is_deep = false;

simplenn_params.nn_name = 'imagenet-vgg-m-2048.mat';
simplenn_params.output_layer = [14];              
simplenn_params.feature_is_deep = true; 
simplenn_params.augment.blur = 0;
simplenn_params.augment.rotation = 0;
simplenn_params.augment.flip = 0;

dagnn_params.nn_name = 'imagenet-resnet-50-dag.mat'; 
dagnn_params.output_var = {'res4ex'};    
dagnn_params.feature_is_deep = true;
dagnn_params.augment.blur = 1;
dagnn_params.augment.rotation = 1;
dagnn_params.augment.flip = 1;

params.t_features = {
    struct('getFeature',@get_fhog,'fparams',hog_params),...
    struct('getFeature',@get_dagnn_layers, 'fparams',dagnn_params),...
    struct('getFeature',@get_table_feature, 'fparams',cn_params),...
};
 struct('getFeature',@get_table_feature, 'fparams',cn_params),...
%    struct('getFeature',@get_simplenn_layers, 'fparams',simplenn_params),...    

% Set [non-deep deep] parameters
params.learning_rate = [0.5 0.05];
params.channel_selection_rate = [0.9 0.075];
params.spatial_selection_rate = [0.1 0.9];
params.output_sigma_factor = [1/16 1/4];	
params.temporal_smoothness_factor = [16 12];
params.stability_factor = [0 0];    

% Image sample parameters
params.search_area_scale = [3.8 4.2];         
params.min_image_sample_size = [150^2 200^2];   
params.max_image_sample_size = [200^2 250^2];  

% Detection parameters
params.refinement_iterations = 1;       
params.newton_iterations = 5;                 

% Set scale parameters
params.number_of_scales = 7;           
params.scale_step = 1.01;       

% Set GPU 
params.use_gpu = true;                 
params.gpu_id = [];              

% Initialisation
params.visualisation = 1;
params.seq = seq;

% Run tracker
[results] = tracker_main(params);